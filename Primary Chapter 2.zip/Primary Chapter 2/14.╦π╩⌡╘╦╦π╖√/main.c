#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int a = 4 + 5 * 3 - 10 / 2 + 11 % 3;
	printf("%d\n", a);
	scanf("%d", &a);
	printf("%d\n", a);
	while (a!=0)
	{
		printf("%d ", a % 10);
		a = a / 10;
	}
	return 0;
}