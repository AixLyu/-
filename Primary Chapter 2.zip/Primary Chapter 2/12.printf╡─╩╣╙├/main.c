#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

int main()
{
	printf("name=%s,age=%d,sex=%c,score=%5.2f\n", "wangdao", 20, 'm', 149.5);
	return 0;
}