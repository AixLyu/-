#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int i = 5;
	float j = i / 2;           //j���2
	float k = (float)i / 2;    //k���2.5
	printf("j=%f,k=%f\n", j, k);
	return 0;
}