#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
//int main()
//{
//	int a[3] = { 2,7,8 };
//	int* p;
//	int j;
//	p = a;  //��ָ�����pָ�����鿪ͷ
//	//j = *p++;    //j=*p; p++       2 2 7
//	j = (*p)++;    //j=*p (*p)++     3 2 3     
//	printf("a[0]=%d,j=%d,*p=%d\n", a[0], j, *p);
//	return 0;
//}
int main()
{
	int a[3] = { 2,7,10 };
	int* p;
	int j;
	p = a;  //��ָ�����pָ�����鿪ͷ
	j = *p++;      //j=*p; p++        2 2 7
	printf("a[0]=%d,j=%d,*p=%d\n", a[0], j, *p);
	j = (*p)++;    //j=*p (*p)++      2 7 8   
	printf("a[0]=%d,j=%d,*p=%d\n", a[0], j, *p);
	j = (*p)++;    //j=*p (*p)++      2 8 9  
	printf("a[0]=%d,j=%d,*p=%d\n", a[0], j, *p);
	return 0;
}
