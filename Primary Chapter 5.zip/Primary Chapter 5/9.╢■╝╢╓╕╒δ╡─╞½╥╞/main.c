#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void change(int** p, int* pj)
{
	*p = pj;
}
int main()
{
	int i = 10;
	int j = 5;
	int* pi ;
	int* pj ;
	pi = &i;
	pj = &j;
	printf("i=%d,*pi=%d,*pj=%d\n", i, *pi, *pj);               //10 10 5
	change(&pi, pj);
	printf("after change:i=%d,*pi=%d,*pj=%d\n", i, *pi, *pj);  //10  5 5
	return 0;
}