#include<stdio.h>
#include<stdlib.h>

void modif_pointer (char*& p)
{
	p = (char*)malloc(100);
	fgets(p, 100, stdin);
}
int main()
{
	char* p;
	modif_pointer(p);
	puts(p);
	return 0;
}