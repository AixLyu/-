#include<stdio.h>
typedef struct Lnode {

	ElemType data;
	struct Londa* next;
}Londe, * LinkList;

int main()
{
	Londe* L;
	L = (LinkList)malloc(sizeof(Londe));
	A->next = B; B->next = C;
	return 0;
}