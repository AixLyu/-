#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
//��׳ˣ������ߣ�
int main()
{
	int i, tmp;
	int n = 0;
	while (scanf("%d", &n) != EOF)
	{
		for (i = 1,tmp=1; i <= n; i++)
		{
			tmp = tmp * i;
		}
		printf("%d\n", tmp);
	}
	return 0;
}
//#include<stdio.h>
//int main()
//{
//	int i, tmp;
//	int n = 0;
//	scanf("%d", &n);
//		for (i = 1, tmp = 1; i <= n; i++)
//		{
//			tmp = tmp * i;
//		}
//	printf("%d\n", tmp);
//	return 0;
//}
