#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>

//����
typedef int ElemType;
typedef struct BSTNode {
	ElemType data;
	struct BSTNode* lchild, * rchild;
}BSTNode,*BiTree;
typedef struct SSTable {
	ElemType* elem;
	int TableLen;
}SSTable;
//����
ElemType BSTInsert(BiTree &T, ElemType p)
{
	if (NULL == T)
	{
		T = (BiTree)malloc(sizeof(BSTNode));
		T->data = p;
		T->lchild = T->rchild = NULL;
		return 1;
	}
 	else if (p == T->data)
	{
		return 0;
	}
	else if (p<T->data)
	{
		return BSTInsert(T->lchild, p);
	}
	else 
	{
		return BSTInsert(T->rchild, p);
	}
}

//������
void CreatBST(BiTree& T, ElemType str[], int n)
{
	T = NULL;
	int i = 0;
	while (i < n)
	{
		BSTInsert(T, str[i]);
		i++;
	}
}

//�������
void InOrder(BiTree T,ElemType str[],int &pos)
{
	if (T != NULL)
	{
		InOrder(T->lchild,str,pos);
		printf("%3d", T->data);
		str[pos++] = T->data;
		InOrder(T->rchild,str,pos);
	}
}

//�۰����
int Binary_Search(SSTable ST, ElemType j)
{
	int low = 0, high = ST.TableLen - 1,mid;
	while (low <= high)
	{
		mid = (high + low) / 2;
		if (j == ST.elem[mid])
		{
			return mid;
		}
		else if (ST.elem[mid] > j)
		{
			high = mid - 1;
		}
		else
		{
			low = mid + 1;
		}
	}
}

int main()
{
	BiTree T=NULL;
	ElemType str[10] = { 0 };
	int i ,j;		
	for (i = 0; i < 10; i++)
	{
		scanf("%d", &str[i]);
	}
	CreatBST(T,str,10);
	int pos=0;
	InOrder(T,str,pos);
	printf("\n");
	SSTable ST;
	ST.elem = str;
	ST.TableLen = 10;
	pos = Binary_Search(ST, 21);
	printf("%d", pos);
	return 0;	
}
