
#include<stdio.h>

int main()
{
	int arr[] = { 0,1,1,2,2,3,1,1,2 };
	for (int i = 0; i < 9; i++)
	{
		printf("%2d", arr[i]);
	}
	return 0;
}