
#include<stdio.h>
//int func2(int x)
//{
//	int m, n;
//	m = x + 1;
//	n = x + 2;
//	return m, n;
//}
//
//int func1(int a, int b)
//{
//	int x = a + b;
//	func2(x);
//	x = x + 10086;
//	return x;
//}
//
//int main()
//{
//	int a = 1, b = 2, c = 3;
//	func1(a, b);
//	c = a + b;
//	printf("%d", c);
//	c=func1(a, b);
//	printf("%d", c);
//	return 0;
//}

int factorial(int n)
{
	if (n == 0 || n == 1)
		return n;
	else
		return n * factorial(n - 1);
}
int main()	
{
	int x;
	factorial(10);
	return 0;
}