#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#define MaxSize 50
typedef int ElemType;
//�ṹ��
typedef struct SqStack{
	ElemType data[MaxSize];
	int top;
}SqStack;
//��ʼ��
void InitStack(SqStack& S)
{
	S.top = -1;
}
//�жϿ�ջ
bool StackEmety(SqStack& S)
{
	if (S.top == -1)
	{
		return true;
	}
	return false;
}
//��ջ
bool Push(SqStack& S,ElemType x)
{
	if (S.top == MaxSize - 1)
		return false;
	S.data[++S.top] = x;
	return true;
}
//��ö�ջԪ��
bool GetTop(SqStack& S, ElemType& x)
{
	if (-1 == S.top)
		return false;
	x = S.data[S.top];
	return true;
}
//��ջ
bool Pop(SqStack& S, ElemType& x)
{
	if (-1 == S.top)
		return false;
	x = S.data[S.top--];
	return true;
}

int main()
{
	SqStack S;
	int x;
	bool ret;
	InitStack(S);
	ret = StackEmety(S);
	if (ret)
	{
		printf("�ǿ�ջ\n");
	}
	else
	{
		printf("���ǿ�ջ\n");
	}
	Push(S, 3);
	Push(S, 4);
	Push(S, 5);
	ret = GetTop(S, x);
	if (ret)
	{
		printf("ջ��Ԫ��Ϊ%d\n", x);
	}
	else
	{
		printf("û��Ԫ��\n");
	}
	ret = Pop(S, x);
	if (ret)
	{
		printf("��ջԪ��Ϊ%d\n", x);
	}
	else
	{
		printf("û�г�ջԪ��\n");
	}
	return 0;
}